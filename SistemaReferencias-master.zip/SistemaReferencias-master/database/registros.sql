/* **************************************************************************************************** *
 * ********************* EN ESTE ARCHIVO SE REGISTRAN TODOS LOS INSERTS ESTATICOS ********************* *
 * **************************************************************************************************** */
USE Referencias;

/* *************************************************** *
 * *********** INSERTS DE TABLA DE NIVELES *********** *
 * *************************************************** */
INSERT INTO nivel (nombre)
VALUES  ('Licenciatura'), 
        ('Maestría'), 
        ('Doctorado'), 
        ('Externo');

/* *************************************************** *
 * ************ INSERTS DE TABLA DE ROLES ************ *
 * *************************************************** */
INSERT INTO rol (nombre, abreviatura) 
VALUES  ('Administrador', 'ADMIN'),
        ('Estudiante', 'ESTU');

/* *************************************************** *
 * *********** INSERTS DE TABLA DE MÓDULOS *********** *
 * *************************************************** */
INSERT INTO modulo (nombre) 
VALUES  ('Usuarios'),
        ('Conceptos'),
        ('Aplicación a Conceptos'),
        ('Referencias');

/* **************************************************************************** *
 * *********** INSERTS DE TABLA DE RELACIONES ENTRE MÓDULOS Y ROLES *********** *
 * **************************************************************************** */
INSERT INTO modulo_rol (modulo_id, rol_id) 
VALUES  (   
            (SELECT modulo_id FROM modulo WHERE nombre = 'Usuarios'),
            (SELECT rol_id FROM rol WHERE nombre = 'Administrador')
        ),
        (
            (SELECT modulo_id FROM modulo WHERE nombre = 'Conceptos'),
            (SELECT rol_id FROM rol WHERE nombre = 'Administrador')
        ),
        (
            (SELECT modulo_id FROM modulo WHERE nombre = 'Aplicación a Conceptos'),
            (SELECT rol_id FROM rol WHERE nombre = 'Administrador')
        ),
        (
            (SELECT modulo_id FROM modulo WHERE nombre = 'Referencias'),
            (SELECT rol_id FROM rol WHERE nombre = 'Administrador')
        ),
        (
            (SELECT modulo_id FROM modulo WHERE nombre = 'Referencias'),
            (SELECT rol_id FROM rol WHERE nombre = 'Estudiante')
        );