/* **************************************************************************************************** *
 * **************** EN ESTE ARCHIVO SE REGISTRAN LAS MODIFICACIONES DEL ESQUEMA INICIAL *************** *
 * **************************************************************************************************** */
USE Referencias;

-- Eliminación de columnas de estudiantes en tabla de usuarios
ALTER TABLE usuario
    MODIFY nivel_id INT NULL
    AFTER usuario_id,
    MODIFY numero_control VARCHAR(9) NULL
    AFTER password;

--Agregar columna de fecha de modificación a tabla historial_conceptos
ALTER TABLE historial_concepto 
	ADD fecha_modificacion DATE 
	AFTER monto_nuevo;

-- Modifica la columna para poner semestre a nula
alter table concepto_nivel modify semestre tinyint null;

-- Modifica la columna para poner usuario_id a nula
alter table referencia modify usuario_id int null;