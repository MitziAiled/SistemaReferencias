/* **************************************************************************************************** *
 * ************************ EN ESTE ARCHIVO SE PUEDEN HACER PRUEBAS O CONSULTAS *********************** *
 * **************************************************************************************************** */
USE Referencias;

INSERT INTO concepto (nombre,descripcion,monto,estado)
VALUES ('Constancia','Constancia de Estudios','50','activo');

INSERT INTO concepto (nombre,descripcion,monto,estado)
VALUES ('Titulo','Titulo Universitario','1000','inactivo');

INSERT INTO concepto (nombre,descripcion,monto,estado)
VALUES ('Clases','Clases Ingles','300','0');

-- Prueba de usuario administrador
INSERT INTO usuario (nombre, primer_apellido, segundo_apellido, curp, sexo, telefono, correo_electronico, password)
VALUES ('Arantxa Patricia', 'Ibarra', 'Muñoz', 'IAMA971003MGTBXR05', false, '4771234567', 'admin@itleon.edu.mx', '4Yc7Wt?f');
-- Asignación de rol a administrador
INSERT INTO rol_usuario (rol_id, usuario_id)
VALUES (    1,
            (SELECT usuario_id FROM usuario WHERE correo_electronico='admin@itleon.edu.mx')
       );
