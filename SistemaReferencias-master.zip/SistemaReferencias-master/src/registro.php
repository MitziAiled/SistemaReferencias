<!-----------------------------------------------------------------------------------------------------------------------------------
                                                            LÓGICA BACKEND
------------------------------------------------------------------------------------------------------------------------------------>
<?php
session_start();

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: dashboard.php");
    exit;
}

require_once "../config.php";

$correo_electronico = $curp = $nombre = $numero_control = $password = $confirma_password = $primer_apellido = $segundo_apellido = $semestre = $sexo = $telefono = $nivel_id = "";
$correo_electronico_err = $curp_err = $nombre_err = $numero_control_err = $password_err = $confirma_password_err = $primer_apellido_err = $semestre_err = $telefono_err = "";
$correoSD = $nivel_id_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    /********************************************************************************************
     *                              VALIDA CREDENCIALES INGRESADAS
     *******************************************************************************************/
    if(empty(trim($_POST["correo_electronico"]))){
        $correo_electronico_err = "Este campo es obligatorio.";
    } elseif(((substr(trim($_POST["correo_electronico"]), -13)) == "itleon.edu.mx") || ((substr(trim($_POST["correo_electronico"]), -13)) == "leon.tecnm.mx")){
        $correoSD = substr(trim($_POST["correo_electronico"]), 0, strpos(trim($_POST["correo_electronico"]), "@"));
        $sql = "SELECT correo_electronico FROM usuario WHERE correo_electronico LIKE '%".$correoSD."%'";
        
        if($stmt = $pdo->prepare($sql)){
            if($stmt->execute()){
                $correo = trim($stmt->fetchColumn());
                $correoNuevo = substr($correo, 0, strpos($correo, "@"));
                if($stmt->rowCount() == 1 || ($correoSD == $correoNuevo)){
                    var_dump($stmt->rowCount());
                    var_dump($correoSD);
                    var_dump($correoNuevo);
                    $correo_electronico_err = "Este correo electrónico ya está en uso. Intenta con otro.";
                } else{
                    $correo_electronico = trim($_POST["correo_electronico"]);
                }
            } else{
                alert("El proceso no se pudo ejecutar. Intenta más tarde.");
            }
            unset($stmt);
        }
    } else{
        $correo_electronico_err = "Debe utilizar un correo institucional.";
    }

    function validate_curp($valor) {     
        if(strlen($valor)==18){         
            $letras     = substr($valor, 0, 4);
            $numeros    = substr($valor, 4, 6);         
            $sexo       = substr($valor, 10, 1);
            $mxState    = substr($valor, 11, 2); 
            $letras2    = substr($valor, 13, 3); 
            $homoclave  = substr($valor, 16, 2);
            if(ctype_alpha($letras) && ctype_alpha($letras2) && ctype_digit($numeros) && ctype_digit($homoclave) && is_mx_state($mxState) && is_sexo_curp($sexo)){ 
                return true; 
            }         
            return false;
        } else{
            return false;
        } 
    }
  
    function is_mx_state($state){     
        $mxStates = [         
            'AS','BS','CL','CS','DF','GT',         
            'HG','MC','MS','NL','PL','QR',         
            'SL','TC','TL','YN','NE','BC',         
            'CC','CM','CH','DG','GR','JC',         
            'MN','NT','OC','QT','SP','SR',         
            'TS','VZ','ZS'     
        ];     
        if(in_array(strtoupper($state),$mxStates)){         
            return true;     
        }     
        return false; 
    }
  
    function is_sexo_curp($sexo){     
        $sexoCurp = ['H','M'];     
        if(in_array(strtoupper($sexo),$sexoCurp)){         
            return true;     
        }     
        return false; 
    }

    if(empty(trim($_POST["curp"]))){
        $curp_err = "Este campo es obligatorio.";     
    } elseif (!validate_curp(trim($_POST["curp"]))){
        $curp_err = "Ingresa una CURP válida.";
    } else{
        $curp = trim($_POST["curp"]);
    }

    if(empty(trim($_POST["nombre"]))){
        $nombre_err = "Este campo es obligatorio.";     
    } else{
        $nombre = trim($_POST["nombre"]);
    }

    if(empty(trim($_POST["numero_control"]))){
        $numero_control_err = "Este campo es obligatorio.";
    } elseif (strlen(trim($_POST["numero_control"])) <= 7 || strlen(trim($_POST["numero_control"])) >= 10) {
        $numero_control_err = "Ingresa un número de control válido.";
    } else{
        $numero_control = trim($_POST["numero_control"]);
    }
    
    $regex = "^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$^";
    if(empty(trim($_POST["password"]))){
        $password_err = "Este campo es obligatorio.";     
    } elseif(!preg_match($regex, trim($_POST["password"]))){
        $password_err = "La contraseña debe tener al menos 8 caracteres, 1 letra minúscula, 1 letra mayúscula, 1 número y 1 caracter especial.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    if(empty(trim($_POST["confirma_password"]))){
        $confirma_password_err = "Este campo es obligatorio.";     
    } else{
        $confirma_password = trim($_POST["confirma_password"]);
        if(empty($password_err) && ($password != $confirma_password)){
            $confirma_password_err = "Las contraseñas no coinciden.";
        }
    }

    if(empty(trim($_POST["primer_apellido"]))){
        $primer_apellido_err = "Este campo es obligatorio.";     
    } else{
        $primer_apellido = trim($_POST["primer_apellido"]);
    }

    if (!empty(trim($_POST["segundo_apellido"]))){
        $segundo_apellido = trim($_POST["segundo_apellido"]);
    }

    if(empty(trim($_POST["semestre"]))){
        $semestre_err = "Este campo es obligatorio.";
    } elseif ((trim($_POST["semestre"]) < 1) || (trim($_POST["semestre"]) > 13)) {
        $semestre_err = "Ingresa un semestre válido.";
    } else{
        $semestre = trim($_POST["semestre"]);
    }

    $sexo = $_POST["sexo"];

    if (strlen(trim($_POST["telefono"])) != 10){
        if (empty(trim($_POST["telefono"]))) {
            $telefono_err = "Este campo es obligatorio.";
        } else {
            $telefono_err = "El número debe ser a 10 dígitos.";
        }
    } else {
        $telefono = trim($_POST["telefono"]);
    }

    if ($_POST["nivel_id"] == 0) {
        $nivel_id_err = "Este campo es obligatorio.";
    } else {
        $nivel_id = $_POST["nivel_id"];
    }
    
    /********************************************************************************************
     *                                      REGISTRA A USUARIO
     *******************************************************************************************/
    if(empty($correo_electronico_err) && empty($curp_err) && empty($nombre_err) && empty($numero_control_err) && empty($password_err) 
        && empty($confirma_password_err) && empty($primer_apellido_err) && empty($semestre_err) && empty($telefono_err)){   
        $sql = "INSERT INTO usuario (correo_electronico, curp, nombre, numero_control, password, primer_apellido, semestre, sexo, telefono, nivel_id";
        $sqlValues = "VALUES ('".$correo_electronico."', '".$curp."', '".$nombre."', '".$numero_control."', '".$password."', '".$primer_apellido."', '".$semestre."', ".$sexo.", '".$telefono."', ".$nivel_id."";

        if (!empty($segundo_apellido)){
            $sql .= ", segundo_apellido";
            $sqlValues .= ", '".$segundo_apellido."'";
        }

        $sql .= ") ".$sqlValues.");";
         
        if($stmt = $pdo->prepare($sql)){
            if($stmt->execute()){
                $lastInsertId = $pdo->lastInsertId();
                /********************************************************************************************
                 *                                      ASIGNA ROL A USUARIO
                 *******************************************************************************************/
                $sql = "INSERT INTO rol_usuario (rol_id, usuario_id) VALUES (
                    (SELECT rol_id FROM rol WHERE nombre = 'Estudiante'), ".$lastInsertId."
                );";

                if($stmt = $pdo->prepare($sql)) {
                    if($stmt->execute()){
                       header("location: ../index.php");
                    } else{
                        alert("El proceso no se pudo ejecutar. Intenta más tarde.");
                    }
                }
            } else{
                alert("El proceso no se pudo ejecutar. Intenta más tarde.");
            }
            unset($stmt);
        }
    }
    unset($pdo);
}
?>


<!-----------------------------------------------------------------------------------------------------------------------------------
                                                            LÓGICA FRONTEND
------------------------------------------------------------------------------------------------------------------------------------>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Fonts and icons -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- Favicon -->
    <link rel="icon" href="../static/favicon.ico">
    <!-- Material Kit CSS -->
    <link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

    <style>
        body {
            background-image: url('../static/bg-login.jpeg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            height:100%;
        }
    </style>
    
    <title>Registro</title>
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-primary sticky-top">
        <div class="container">
            <a class="navbar-brand" href="../index.php">Referencias</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">Inicio de sesión</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="registro.php">Registro<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="referencias/generar_ref_ext.php">Generador de referencia</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-10 shadow-lg p-3 bg-white rounded">
                <div>
                    <img style="display:block; margin-left:auto; margin-right:auto;pointer-events:none;" src="../static/icon-registro.png">
                    <h2 class="h2 text-center">Registro</h4>
                    <p class="text-center">Por favor ingresa tus datos para crear una cuenta.</p>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

                        <div class="form-row justify-content-around">

                            <div class="form-group col-md-3 <?php echo (!empty($nombre_err)) ? : ''; ?>">
                                <label>Nombre</label>
                                <input type="text" name="nombre" class="form-control" value="<?php echo $nombre; ?>">
                                <?php
                                if(!empty($nombre_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $nombre_err; ?></small>
                                <?php }
                                ?>
                            </div>

                            <div class="form-group col-md-3 <?php echo (!empty($primer_apellido_err)) ? 'has-error' : ''; ?>">
                                <label>Primer apellido</label>
                                <input type="text" name="primer_apellido" class="form-control" value="<?php echo $primer_apellido; ?>">
                                <?php
                                if(!empty($primer_apellido_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $primer_apellido_err; ?></small>
                                <?php }
                                ?>
                            </div>

                            <div class="form-group col-md-3">
                                <label>Segundo apellido</label>
                                <input type="text" name="segundo_apellido" class="form-control" value="<?php echo $segundo_apellido; ?>">
                            </div>
                        </div>

                        <div class="form-row justify-content-around">
                            <div class="form-group col-md-3 <?php echo (!empty($correo_electronico_err)) ? : ''; ?>">
                                <label>Correo electrónico</label>
                                <input type="text" name="correo_electronico" class="form-control" value="<?php echo $correo_electronico; ?>">
                                <?php
                                if(!empty($correo_electronico_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $correo_electronico_err; ?></small>
                                <?php }
                                ?>
                            </div>

                            <div class="form-group col-md-3 <?php echo (!empty($curp_err)) ? 'has-error' : ''; ?>">
                                <label>CURP</label>
                                <input type="text" name="curp" class="form-control" value="<?php echo $curp; ?>">
                                <label style="font-size:13px;">¿No conoces tu CURP?<a href="https://www.gob.mx/curp/" target="_blank"> Da clic aquí.</a></label>
                                <?php
                                if(!empty($curp_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $curp_err; ?></small>
                                <?php }
                                ?>
                            </div>

                            <div class="form-group col-md-3">
                                <label>Género</label>
                                <div class="form-check form-check-radio">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="radio" name="sexo" value="false" checked>
                                        Femenino
                                        <span class="circle">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                                <div class="form-check form-check-radio">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="radio" name="sexo" value="true" >
                                        Masculino
                                        <span class="circle">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-row justify-content-around">
                            <div class="form-group col-md-3 <?php echo (!empty($password_err)) ? : ''; ?>">
                                <label>Contraseña</label>
                                <input type="password" name="password" class="form-control" value="<?php echo $password; ?>"><?php
                                if(!empty($password_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $password_err; ?></small>
                                <?php }
                                ?>
                            </div>
                            <div class="form-group col-md-3 <?php echo (!empty($confirma_password_err)) ? 'has-error' : ''; ?>">
                                <label>Confirma tu contraseña</label>
                                <input type="password" name="confirma_password" class="form-control" value="<?php echo $confirma_password; ?>"><?php
                                if(!empty($confirma_password_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $confirma_password_err; ?></small>
                                <?php }
                                ?>
                            </div>
                            <div class="form-group col-md-3 <?php echo (!empty($numero_control_err)) ? : ''; ?>">
                                <label>Número de control</label>
                                <input type="text" name="numero_control" class="form-control" value="<?php echo $numero_control; ?>"><?php
                                if(!empty($numero_control_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $numero_control_err; ?></small>
                                <?php }
                                ?>
                            </div>
                        </div>
                        

                        <div class="form-row justify-content-around">
                            <div class="form-group col-md-3 <?php echo (!empty($telefono_err)) ? : ''; ?>">
                                <label>Teléfono</label>
                                <input type="text" name="telefono" class="form-control" value="<?php echo $telefono; ?>"><?php
                                if(!empty($telefono_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $telefono_err; ?></small>
                                <?php }
                                ?>
                            </div>
                            <div class="form-group col-md-3 <?php echo (!empty($semestre_err)) ? : ''; ?>">
                                <label>Semestre</label>
                                <input type="text" name="semestre" class="form-control" value="<?php echo $semestre; ?>"><?php
                                if(!empty($semestre_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $semestre_err; ?></small>
                                <?php }
                                ?>
                            </div>
                            <div class="form-group col-md-3">
                                <label>Nivel académico</label>
                                <select class="form-control" name="nivel_id" style="margin-top:-5px;">
                                    <option value="0" selected>Elige uno...</option>
                                    <option value="1">Licenciatura</option>
                                    <option value="11">Maestria</option>
                                    <option value="21">Doctorado</option>
                                </select><?php
                                if(!empty($nivel_id_err)){?>
                                  <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $nivel_id_err; ?></small>
                                <?php }
                                ?>
                            </div>
                        </div>
                        <div class="form-group text-center">
                            <input type="submit" class="btn btn-primary" value="Registrar">
                        </div>
                        <p class="text-center">¿Tienes cuenta? <a href="../index.php">Inicia sesión</a>.</p>
                    </form>
                </div>
            </div>
        </div>
    </div>    
</body>
</html>