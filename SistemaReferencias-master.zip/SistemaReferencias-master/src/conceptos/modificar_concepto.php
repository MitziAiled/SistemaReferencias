<?php 
session_start();

if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../../index.php");
    exit;
}

if (isset($_SESSION["loggedin"]) && $_SESSION["rol_id"] == 11) {
    header("location: ../dashboard.php");
}

?>
<?php date_default_timezone_set('America/Mexico_City'); ?>
<?php
require_once "../../config.php";

if( isset($_POST['nombre']) ) {
        $nombre = $_POST['nombre'];
     }
if( isset($_POST['descripcion']) ) {
        $descripcion = $_POST['descripcion'];
     }
if( isset($_POST['monto']) ) {
        $monto = $_POST['monto'];
     }
if( isset($_POST['fecha_mod']) ) {
        $fecha_mod = $_POST['fecha_mod'];
     }
    
try {

	$sql = "UPDATE concepto SET " 
		."nombre= '".$nombre."', "
		."descripcion= '".$descripcion."', "
		."monto= '".$monto."' "
		." WHERE concepto_id=".$_POST['id'];
    $query = $pdo->prepare($sql);
    $query->execute();

    $sql = "SELECT * from historial_concepto WHERE concepto_id=".$_POST['id'];
    $query = $pdo->prepare($sql);
    $query->execute();
    $montoBD = $query->fetchAll(PDO::FETCH_OBJ);  

    $filas = $query->rowCount();  

    $monto_antes=trim($montoBD[$filas-1]->monto_anterior);
    $monto_nuevo=trim($montoBD[$filas-1]->monto_nuevo);

    if($monto_nuevo !== $monto){
    	$sql = "INSERT into historial_concepto (concepto_id, monto_anterior, monto_nuevo, fecha_modificacion) 
    			VALUES ("
    			.$_POST['id'].","
				.$monto_nuevo.","
				.$monto.",'"
				.$fecha_mod."')";
    	$query = $pdo->prepare($sql);
    	$query->execute();
    }

    $pdo = null;

	header('Location: formulario_consulta.php');
	unset($pdo);
    unset($query);
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>