<?php
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../../index.php");
    exit;
}

if (isset($_SESSION["loggedin"]) && $_SESSION["rol_id"] == 11) {
    header("location: ../dashboard.php");
}

date_default_timezone_set('America/Mexico_City');

require_once "../../config.php";

if( isset($_POST['nombre']) ) {
        $nombre = $_POST['nombre'];
     }
if( isset($_POST['descripcion']) ) {
        $descripcion = $_POST['descripcion'];
     }
if( isset($_POST['monto']) ) {
        $monto = $_POST['monto'];
     }

if( isset($_POST['estado']) ) {
        $estado = $_POST['estado'];
     }

if( isset($_POST['fecha']) ) {
        $fecha = $_POST['fecha'];
     }

 
try {
    $sql = "INSERT INTO concepto (nombre, descripcion, monto)
            VALUES (
                '".$nombre."', '"
                .$descripcion."', '"
                .$monto."')";
    $query = $pdo->prepare($sql);
    $query->execute();
    $lastId = $pdo->lastInsertId();

    $sql = "INSERT INTO historial_concepto (concepto_id, monto_anterior, monto_nuevo, fecha_modificacion)
             VALUES ("
                .$lastId.","
                .$monto.","
                .$monto.",'"
                .$fecha."')";

    $query = $pdo->prepare($sql);
    $query->execute();

    $pdo = null;

    header('Location: formulario_consulta.php');
    unset($pdo);
    unset($query);
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>