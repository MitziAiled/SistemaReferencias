<!---------------------------------------------------------------------------------------
                                        LÓGICA BACKEND
---------------------------------------------------------------------------------------->
<?php
session_start();
 
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../../index.php");
    exit;
}

if (isset($_SESSION["loggedin"]) && $_SESSION["rol_id"] == 11) {
    header("location: ../dashboard.php");
}

require_once "../../config.php";

/*****************************************************************************
                        PARA CONSULTAR TODOS LOS USUARIOS
 *****************************************************************************/
$sql = "SELECT u.usuario_id, u.nombre, u.primer_apellido, u.segundo_apellido, u.numero_control, u.correo_electronico FROM usuario AS u INNER JOIN rol_usuario AS ru WHERE u.usuario_id = ru.usuario_id AND ru.rol_id = 11 AND estado = 1";
$query = $pdo->prepare($sql);
$query->execute();
$usuariosBD = $query->fetchAll(PDO::FETCH_OBJ);
$usuarios = array();

if ($query->rowCount() > 0) {
    foreach ($usuariosBD as $usuario) {
        $usuarios[] = $usuario;
    }
}

/*****************************************************************************
                            PARA FILTRAR USUARIOS
 *****************************************************************************/
if(isset($_POST['consultar'])){
    $filtro = trim($_POST["numero_control"]);

    if (!empty($filtro)) {
        $sql = "SELECT u.usuario_id, u.nombre, u.primer_apellido, u.segundo_apellido, u.numero_control, u.correo_electronico FROM usuario AS u INNER JOIN rol_usuario AS ru WHERE u.usuario_id = ru.usuario_id AND ru.rol_id = 11 AND estado = 1 AND u.numero_control LIKE '%".$filtro."%'";
        $query = $pdo->prepare($sql);
        $query->execute();
        $usuariosBD = $query->fetchAll(PDO::FETCH_OBJ);
        $usuarios = array();

        if ($query->rowCount() > 0) {
            foreach ($usuariosBD as $usuario) {
                $usuarios[] = $usuario;
            }
        }
    } else {
        $sql = "SELECT u.usuario_id, u.nombre, u.primer_apellido, u.segundo_apellido, u.numero_control, u.correo_electronico FROM usuario AS u INNER JOIN rol_usuario AS ru WHERE u.usuario_id = ru.usuario_id AND ru.rol_id = 11 AND estado = 1";
        $query = $pdo->prepare($sql);
        $query->execute();
        $usuariosBD = $query->fetchAll(PDO::FETCH_OBJ);
        $usuarios = array();

        if ($query->rowCount() > 0) {
            foreach ($usuariosBD as $usuario) {
                $usuarios[] = $usuario;
            }
        }
    }
    unset($query);
}

/*****************************************************************************
                            PARA ELIMINAR USUARIO LOGICAMENTE
 *****************************************************************************/
if(isset($_POST['eliminar'])){
    $usuario_id=trim($_POST['usuario_id']);

    $consulta = "UPDATE usuario SET estado = 0 WHERE `usuario_id`=:usuario_id";
    $sql = $pdo->prepare($consulta);
    $sql->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
    $sql->execute();

    unset($query);
    header("location:usuarios.php");
}

unset($query);
unset($pdo);
?>

<!---------------------------------------------------------------------------------------
                                        LÓGICA FRONTEND
----------------------------------------------------------------------------------------> 
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Favicon -->
  <link rel="icon" href="../../static/favicon.ico">
  <!-- CSS Files -->
  <link href="../../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <title>Usuarios</title>
</head>

<body>
    <div class="wrapper ">
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="../../assets/img/sidebar-1.jpg">
            <div class="logo">
                <a href="../dashboard.php" class="simple-text logo-normal">Referencias</a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item  ">
                        <a class="nav-link" href="../dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="../referencias/consulta_admin.php">
                            <i class="material-icons">description</i>
                            <p>Referencias</p>
                        </a>
                    </li>
                    <!-- Si es un administrador, mostrar los demas módulos -->
                    <?php
                    if(htmlspecialchars($_SESSION["rol_id"]) == 1) {?>
                        <li class="nav-item ">
                            <a class="nav-link" href="usuarios.php">
                                <i class="material-icons">person</i>
                                <p>Usuarios</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="../conceptos/formulario_consulta.php">
                                <i class="material-icons">table_chart</i>
                                <p>Conceptos</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="../relacion/consultar_relacion.php">
                                <i class="material-icons">dynamic_feed</i>
                                <p>Aplicación a Conceptos</p>
                            </a>
                        </li>
                    <?php }
                    ?>
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <h1 class="navbar-brand">Usuarios</h1>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                    </button>
                    <div class="justify-content-end">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown" data-toggle="dropdown">
                                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">person</i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                                    <form action="../logout.php">
                                        <button style="cursor:pointer;width:93%;" type="submit" class="dropdown-item">Cerrar sesión</button>
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h3 class="card-title">Administración de Usuarios</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-title text-center">
                                        <div class="row justify-content-around">
                                            <form class="form-inline justify-content-center col-md-12 mt-3 mb-3" method="POST" action="<?php $_SERVER['PHP_SELF']?>">
                                                <input class="form-control" type="text" placeholder="Número de control" aria-label="Número de control" name="numero_control">
                                                <button class="btn btn-primary btn-rounded btn-sm" type="submit" name="consultar">Buscar</button>
                                            </form>
                                        </div>
                                        </div>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">No.</th>
                                                    <th class="text-center">Nombre completo</th>
                                                    <th class="text-center">Número de control</th>
                                                    <th class="text-center">Correo electrónico</th>
                                                    <th class="text-left">Opciones</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if (!empty($usuarios)) {
                                                    $i = 0;
                                                    foreach ($usuarios as $usuario) {
                                                        $i++;
                                                        ?>
                                                        <tr>
                                                            <td class="text-center">
                                                                <?php
                                                                echo ($i);
                                                                ?>
                                                            </td>
                                                            <td class="text-center">
                                                                <?php
                                                                echo ($usuario->nombre." ".$usuario->primer_apellido." ".$usuario->segundo_apellido);
                                                                ?>
                                                            </td>
                                                            <td class="text-center">
                                                                <?php
                                                                echo ($usuario->numero_control);
                                                                ?>
                                                            </td>
                                                            <td class="text-center">
                                                                <?php
                                                                echo ($usuario->correo_electronico);
                                                                ?>
                                                            </td>
                                                            <td class="td-actions text-center form-inline">
                                                                <form method='POST' action="consulta-usuario.php">
                                                                    <input type="hidden" name="usuario_id" value="<?php echo($usuario->usuario_id); ?>">
                                                                    <button type="submit" class="btn btn-info" rel="tooltip" name='consulta_usuario'>
                                                                        <i class="material-icons">person</i>
                                                                    </button>
                                                                </form>
                                                                <form method='POST' action="modifica-usuario.php">
                                                                    <input type="hidden" name="usuario_id" value="<?php echo($usuario->usuario_id); ?>">
                                                                    <button type="submit" class="btn btn-success" rel="tooltip">
                                                                        <i class="material-icons">edit</i>
                                                                    </button>
                                                                </form>
                                                                <form onsubmit="return confirm('¿Realmente deseas eliminar al usuario?');" method='POST' action="<?php $_SERVER['PHP_SELF']?>">
                                                                    <input type="hidden" name="usuario_id" value="<?php echo($usuario->usuario_id); ?>">
                                                                    <button type="submit" class="btn btn-danger" rel="tooltip" name='eliminar'>
                                                                        <i class="material-icons">close</i>
                                                                    </button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                    <?php }
                                                } else { ?>
                                                <tr>
                                                    <td colspan="5" class="text-center">No hay usuarios registrados.</td>
                                                </tr>
                                                <?php }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--   Core JS Files   -->
    <script src="../../assets/js/core/jquery.min.js"></script>
    <script src="../../assets/js/core/popper.min.js"></script>
    <script src="../../assets/js/core/bootstrap-material-design.min.js"></script>
    <script src="../../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!-- Plugin for the momentJs  -->
    <script src="../../assets/js/plugins/moment.min.js"></script>
    <!--  Plugin for Sweet Alert -->
    <script src="../../assets/js/plugins/sweetalert2.js"></script>
    <!-- Forms Validations Plugin -->
    <script src="../../assets/js/plugins/jquery.validate.min.js"></script>
    <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
    <script src="../../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
    <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
    <script src="../../assets/js/plugins/bootstrap-selectpicker.js"></script>
    <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
    <script src="../../assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
    <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
    <script src="../../assets/js/plugins/jquery.dataTables.min.js"></script>
    <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
    <script src="../../assets/js/plugins/bootstrap-tagsinput.js"></script>
    <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
    <script src="../../assets/js/plugins/jasny-bootstrap.min.js"></script>
    <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
    <script src="../../assets/js/plugins/fullcalendar.min.js"></script>
    <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
    <script src="../../assets/js/plugins/jquery-jvectormap.js"></script>
    <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="../../assets/js/plugins/nouislider.min.js"></script>
    <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
    <!-- Library for adding dinamically elements -->
    <script src="../../assets/js/plugins/arrive.min.js"></script>
    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <!-- Chartist JS -->
    <script src="../../assets/js/plugins/chartist.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  
    <script>
    $(document).ready(function() {
        $().ready(function() {
            $sidebar = $('.sidebar');
            $sidebar_img_container = $sidebar.find('.sidebar-background');
            $full_page = $('.full-page');
            $sidebar_responsive = $('body > .navbar-collapse');
            window_width = $(window).width();
            fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();
            if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
                if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
                    $('.fixed-plugin .dropdown').addClass('open');
                }
            }

            $('.fixed-plugin a').click(function(event) {
                // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
                if ($(this).hasClass('switch-trigger')) {
                    if (event.stopPropagation) {
                        event.stopPropagation();
                    } else if (window.event) {
                        window.event.cancelBubble = true;
                    }
                }
            });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
    <script>
    $(document).ready(function() {
        //init DateTimePickers
        md.initFormExtendedDatetimepickers();
    });
    </script>
</body>
</html>