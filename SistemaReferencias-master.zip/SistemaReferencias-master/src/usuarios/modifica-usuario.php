<!---------------------------------------------------------------------------------------
                                        LÓGICA BACKEND
---------------------------------------------------------------------------------------->
<?php
session_start();
 
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../../index.php");
    exit;
}

if (isset($_SESSION["loggedin"]) && $_SESSION["rol_id"] == 11) {
    header("location: ../dashboard.php");
}

require_once "../../config.php";

/*****************************************************************************
                                PARA OBTENER ESTUDIANTE
 *****************************************************************************/
$usuario_id = $nivel_id = $nombre = $primer_apellido = $segundo_apellido = $curp = $sexo = $telefono = $correo_electronico = $numero_control = $semestre = $correoSD = "";

$nivel_id_err = $nombre_err = $primer_apellido_err = $segundo_apellido_err = $curp_err = $telefono_err = $correo_electronico_err = $numero_control_err = $semestre_err = "";

if(isset($_POST["usuario_id"])){
	$sql = "SELECT * FROM usuario WHERE usuario_id=".$_POST["usuario_id"];
	$query = $pdo->prepare($sql);
	$query->execute();
	$usuario = $query->fetchAll(PDO::FETCH_OBJ);
	
	// Guardamos los datos personales del usuario
	$usuario_id=$usuario[0]->usuario_id;
	$nivel_id=trim($usuario[0]->nivel_id);
	$nombre=trim($usuario[0]->nombre);
	$primer_apellido=trim($usuario[0]->primer_apellido);
	if (!empty(trim($usuario[0]->segundo_apellido))) {
		$segundo_apellido=trim($usuario[0]->segundo_apellido);
	}
	$curp=trim($usuario[0]->curp);
	$sexo=trim($usuario[0]->sexo);
	$telefono=trim($usuario[0]->telefono);
	$correo_electronico=trim($usuario[0]->correo_electronico);
	$numero_control=trim($usuario[0]->numero_control);
    $semestre=trim($usuario[0]->semestre);
    
    unset($query);
} elseif(isset($_POST["id"])) {
    $usuario_id = $_POST["id"];
	/**********************************************************************************************
							        VALIDACION DE CAMPOS OBLIGATORIOS
    **********************************************************************************************/
    if(empty(trim($_POST["correo_electronico"]))){
        $correo_electronico_err = "Este campo es obligatorio.";
    } elseif(((substr(trim($_POST["correo_electronico"]), -13)) == "itleon.edu.mx") || ((substr(trim($_POST["correo_electronico"]), -13)) == "leon.tecnm.mx")){
        // Obtiene el correo sin dominio
        $correoSD == substr(trim($_POST["correo_electronico"]), 0, strpos(trim($_POST["correo_electronico"]), "@"));
        // Busca un correo parecido
        $sql = "SELECT correo_electronico FROM usuario WHERE correo_electronico LIKE '%".$correoSD."%'";
        
        if($stmt = $pdo->prepare($sql)){
            if($stmt->execute()){
                $correo = trim($stmt->fetchColumn());
                $correoNuevo = substr($correo, 0, strpos($correo, "@"));
                if($stmt->rowCount() == 1 || ($correoSD == $correoNuevo)){
                    $correo_electronico_err = "Este correo electrónico ya está en uso. Intenta con otro.";
                } else{
                    $correo_electronico = trim($_POST["correo_electronico"]);
                }
            } else{
                alert("El proceso no se pudo ejecutar. Intenta más tarde.");
            }
            unset($stmt);
        }
    } else{
        $correo_electronico_err = "Debe utilizar un correo institucional.";
    }

    // Funciones para validar curp
    function validate_curp($valor) {     
        if(strlen($valor)==18){         
            $letras     = substr($valor, 0, 4);
            $numeros    = substr($valor, 4, 6);         
            $sexo       = substr($valor, 10, 1);
            $mxState    = substr($valor, 11, 2); 
            $letras2    = substr($valor, 13, 3); 
            $homoclave  = substr($valor, 16, 2);
            if(ctype_alpha($letras) && ctype_alpha($letras2) && ctype_digit($numeros) && ctype_digit($homoclave) && is_mx_state($mxState) && is_sexo_curp($sexo)){ 
                return true; 
            }         
            return false;
        } else{
            return false;
        } 
    }
  
    function is_mx_state($state){     
        $mxStates = [         
            'AS','BS','CL','CS','DF','GT',         
            'HG','MC','MS','NL','PL','QR',         
            'SL','TC','TL','YN','NE','BC',         
            'CC','CM','CH','DG','GR','JC',         
            'MN','NT','OC','QT','SP','SR',         
            'TS','VZ','ZS'     
        ];     
        if(in_array(strtoupper($state),$mxStates)){         
            return true;     
        }     
        return false; 
    }
  
    function is_sexo_curp($sexo){     
        $sexoCurp = ['H','M'];     
        if(in_array(strtoupper($sexo),$sexoCurp)){         
            return true;     
        }     
        return false; 
    }

    if(empty(trim($_POST["curp"]))){
        $curp_err = "Este campo es obligatorio.";     
    } elseif (!validate_curp(trim($_POST["curp"]))){
        $curp_err = "Ingresa una CURP válida.";
    } else{
        $curp = trim($_POST["curp"]);
    }

    if(empty(trim($_POST["nombre"]))){
        $nombre_err = "Este campo es obligatorio.";     
    } else{
        $nombre = trim($_POST["nombre"]);
    }

    if(empty(trim($_POST["numero_control"]))){
        $numero_control_err = "Este campo es obligatorio.";
    } elseif (strlen(trim($_POST["numero_control"])) <= 7 || strlen(trim($_POST["numero_control"])) >= 10) {
        $numero_control_err = "Ingresa un número de control válido.";
    } else{
        $numero_control = trim($_POST["numero_control"]);
    }

    if(empty(trim($_POST["primer_apellido"]))){
        $primer_apellido_err = "Este campo es obligatorio.";     
    } else{
        $primer_apellido = trim($_POST["primer_apellido"]);
    }

    if (!empty(trim($_POST["segundo_apellido"]))){
        $segundo_apellido = trim($_POST["segundo_apellido"]);
    }

    if(empty(trim($_POST["semestre"]))){
        $semestre_err = "Este campo es obligatorio.";
    } elseif ((trim($_POST["semestre"]) < 0) || (trim($_POST["semestre"]) > 13)) {
        $semestre_err = "Ingresa un semestre válido.";
    } else{
        $semestre = trim($_POST["semestre"]);
    }

    $sexo = $_POST["sexo"];

    if (strlen(trim($_POST["telefono"])) != 10){
        if (empty(trim($_POST["telefono"]))) {
            $telefono_err = "Este campo es obligatorio.";
        } else {
            $telefono_err = "El número debe ser a 10 dígitos.";
        }
    } else {
        $telefono = trim($_POST["telefono"]);
    }

    if ($_POST["nivel_id"] == 0) {
        $nivel_id_err = "Este campo es obligatorio.";
    } else {
        $nivel_id = $_POST["nivel_id"];
    }

	/**********************************************************************************************
									    ACTUALIZA DATOS DEL USUARIO
	**********************************************************************************************/
    if(empty($correo_electronico_err) && empty($curp_err) && empty($nombre_err) && empty($numero_control_err) 
        && empty($primer_apellido_err) && empty($semestre_err) && empty($telefono_err) && empty($nivel_id_err)){

		// Update de campos obligatorios de pacientes
		$sqlUpdateUsuario = "UPDATE usuario
		SET correo_electronico='".$correo_electronico."',
		nombre='".$nombre."',
		primer_apellido='".$primer_apellido."',
		segundo_apellido='".$segundo_apellido."',
		sexo=".$sexo.",
		curp='".$curp."',
		numero_control='".$numero_control."',
		semestre=".$semestre.",
		telefono='".$telefono."',
		nivel_id=".$nivel_id." WHERE usuario_id=".$usuario_id.";";

		$pdo->exec($sqlUpdateUsuario);
		
		header('Location: usuarios.php');

	}
} else {
	header('Location: usuarios.php');
}

unset($pdo);
?>

<!---------------------------------------------------------------------------------------
                                        LÓGICA FRONTEND
---------------------------------------------------------------------------------------->
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Favicon -->
  <link rel="icon" href="../../static/favicon.ico">
  <!-- CSS Files -->
  <link href="../../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <title>Modificación de Usuarios</title>
</head>

<body>
    <!-- Inicio de todo -->
    <div class="wrapper ">
        <!-- Inicio menu de hamburguesa -->
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="../../assets/img/sidebar-1.jpg">
            <!-- Inicio titulo de sidebar -->
            <div class="logo">
                <a href="../dashboard.php" class="simple-text logo-normal">Referencias</a>
            </div>
            <!-- Fin titulo de sidebar -->

            <!-- Inicio elementos de menu -->
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item  ">
                        <a class="nav-link" href="../dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="#">
                            <i class="material-icons">description</i>
                            <p>Referencias</p>
                        </a>
                    </li>
                    <!-- Si es un administrador, mostrar los demas módulos -->
                    <?php
                    if(htmlspecialchars($_SESSION["rol_id"]) == 1) {?>
                        <li class="nav-item ">
                            <a class="nav-link" href="usuarios.php">
                                <i class="material-icons">person</i>
                                <p>Usuarios</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="../conceptos/formulario_consulta.php">
                                <i class="material-icons">table_chart</i>
                                <p>Conceptos</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="../relacion/consultar_relacion.php">
                                <i class="material-icons">dynamic_feed</i>
                                <p>Aplicación a Conceptos</p>
                            </a>
                        </li>
                    <?php }
                    ?>
                </ul>
            </div>
            <!-- Fin elementos de menu -->
        </div>
        <!-- Fin menu de hamburguesa -->

        <!-- Inicio de panel -->
        <div class="main-panel">
            <!-- Inicio menú de logout -->
            <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <h1 class="navbar-brand">Usuarios</h1>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                    </button>
                    <div class="justify-content-end">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown" data-toggle="dropdown">
                                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">person</i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                                    <form action="../logout.php">
                                        <button style="cursor:pointer;width:93%;" type="submit" class="dropdown-item">Cerrar sesión</button>
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- Fin menú logout -->

            <!-- Inicio de dashboard -->
            <div class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h3 class="card-title">Modificación de Usuario</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-title text-center mt-3">
                                        <form action="<?php $_SERVER["PHP_SELF"];?>" method="POST" onsubmit="return confirm('¿Realmente deseas modificar los datos del usuario?');">
                                            
                                            <div class="form-row justify-content-around">
                                                <div class="form-group col-md-3 <?php echo (!empty($nombre_err)) ? : ''; ?>">
                                                    <label>Nombre</label>
                                                    <input type="text" name="nombre" class="form-control" value="<?php echo $nombre; ?>">
                                                    <?php
                                                    if(!empty($nombre_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $nombre_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>

                                                <div class="form-group col-md-3 <?php echo (!empty($primer_apellido_err)) ? 'has-error' : ''; ?>">
                                                    <label>Primer apellido</label>
                                                    <input type="text" name="primer_apellido" class="form-control" value="<?php echo $primer_apellido; ?>">
                                                    <?php
                                                    if(!empty($primer_apellido_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $primer_apellido_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>

                                                <div class="form-group col-md-3">
                                                    <label>Segundo apellido</label>
                                                    <input type="text" name="segundo_apellido" class="form-control" value="<?php echo $segundo_apellido; ?>">
                                                </div>
                                            </div>

                                            <div class="form-row justify-content-around mt-5">
                                                <div class="form-group col-md-3 <?php echo (!empty($correo_electronico_err)) ? : ''; ?>">
                                                    <label>Correo electrónico</label>
                                                    <input type="text" name="correo_electronico" class="form-control" value="<?php echo $correo_electronico; ?>">
                                                    <?php
                                                    if(!empty($correo_electronico_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $correo_electronico_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>

                                                <div class="form-group col-md-3 <?php echo (!empty($curp_err)) ? 'has-error' : ''; ?>">
                                                    <label>CURP</label>
                                                    <input type="text" name="curp" class="form-control" value="<?php echo $curp; ?>">
                                                    <?php
                                                    if(!empty($curp_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $curp_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>

                                                <div class="form-group col-md-3" style="margin-top:-20px;">
                                                    <label>Género</label>
                                                    <div class="form-check form-check-radio">
                                                        <label class="form-check-label">
                                                            <input class="form-check-input" type="radio" name="sexo" value="false" <?php
                                                            if (!$sexo) { ?>
                                                                checked
                                                            <?php }
                                                            ?>>
                                                            Femenino
                                                            <span class="circle">
                                                                <span class="check"></span>
                                                            </span>
                                                        </label>
                                                    </div>
                                                    <div class="form-check form-check-radio">
                                                        <label class="form-check-label">
                                                            <input class="form-check-input" type="radio" name="sexo" value="true" <?php
                                                            if($sexo) { ?>
                                                                checked
                                                            <?php }
                                                            ?>>
                                                            Masculino
                                                            <span class="circle">
                                                                <span class="check"></span>
                                                            </span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-row justify-content-around mt-5">
                                                <div class="form-group col-md-3 <?php echo (!empty($numero_control_err)) ? : ''; ?>">
                                                    <label>Número de control</label>
                                                    <input type="text" name="numero_control" class="form-control" value="<?php echo $numero_control; ?>"><?php
                                                    if(!empty($numero_control_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $numero_control_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                                <div class="form-group col-md-3 <?php echo (!empty($telefono_err)) ? : ''; ?>">
                                                    <label>Teléfono</label>
                                                    <input type="text" name="telefono" class="form-control" value="<?php echo $telefono; ?>"><?php
                                                    if(!empty($telefono_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $telefono_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                                <div class="form-group col-md-3 <?php echo (!empty($semestre_err)) ? : ''; ?>">
                                                    <label>Semestre</label>
                                                    <input type="text" name="semestre" class="form-control" value="<?php echo $semestre; ?>"><?php
                                                    if(!empty($semestre_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $semestre_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>


                                            <div class="form-row justify-content-around mt-5">
                                                <div class="form-group col-md-3">
                                                    <label>Nivel académico</label>
                                                    <select class="form-control" name="nivel_id" style="margin-top:-5px;">
                                                        <option value="1" <?php
                                                        if ($nivel_id == 1) { ?>
                                                            selected
                                                        <?php }
                                                        ?>>Licenciatura</option>
                                                        <option value="11" <?php
                                                        if($nivel_id == 11) { ?>
                                                            selected
                                                        <?php }
                                                        ?>>Maestría</option>
                                                        <option value="21" <?php
                                                        if($nivel_id == 21) { ?>
                                                            selected
                                                        <?php }
                                                        ?>>Doctorado</option>
                                                    </select><?php
                                                    if(!empty($nivel_id_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $nivel_id_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="form-group text-center">
                                                <input type="submit" class="btn btn-primary" value="Modificar usuario">
                                            </div>
                                            <input type="hidden" name="id" value="<?php echo $usuario_id ?>">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Fin de dashboard -->
        </div>
        <!-- Fin de panel -->
    </div>
    <!-- Inicio de todo -->
    
    <!--   Core JS Files   -->
    <script src="../../assets/js/core/jquery.min.js"></script>
    <script src="../../assets/js/core/popper.min.js"></script>
    <script src="../../assets/js/core/bootstrap-material-design.min.js"></script>
    <script src="../../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!-- Plugin for the momentJs  -->
    <script src="../../assets/js/plugins/moment.min.js"></script>
    <!--  Plugin for Sweet Alert -->
    <script src="../../assets/js/plugins/sweetalert2.js"></script>
    <!-- Forms Validations Plugin -->
    <script src="../../assets/js/plugins/jquery.validate.min.js"></script>
    <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
    <script src="../../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
    <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
    <script src="../../assets/js/plugins/bootstrap-selectpicker.js"></script>
    <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
    <script src="../../assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
    <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
    <script src="../../assets/js/plugins/jquery.dataTables.min.js"></script>
    <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
    <script src="../../assets/js/plugins/bootstrap-tagsinput.js"></script>
    <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
    <script src="../../assets/js/plugins/jasny-bootstrap.min.js"></script>
    <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
    <script src="../../assets/js/plugins/fullcalendar.min.js"></script>
    <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
    <script src="../../assets/js/plugins/jquery-jvectormap.js"></script>
    <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="../../assets/js/plugins/nouislider.min.js"></script>
    <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
    <!-- Library for adding dinamically elements -->
    <script src="../../assets/js/plugins/arrive.min.js"></script>
    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <!-- Chartist JS -->
    <script src="../../assets/js/plugins/chartist.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }

        }

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      md.initFormExtendedDatetimepickers();
    });
  </script>
</body>

</html>