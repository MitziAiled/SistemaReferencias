<?php
$server = 'us-cdbr-east-06.cleardb.net';
$username = 'b9c8d2bfcd37e6';
$password = 'a945d416';
$database_name = 'heroku_0ceeed9fadd0855';

$conexion = new mysqli($server,$username,$password,$database_name);
?>