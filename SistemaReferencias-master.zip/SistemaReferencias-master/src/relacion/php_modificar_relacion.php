<?php 
	require_once "../../config.php";
	
	if( isset($_POST['concepto_id']) ) {
			$concepto_id = $_POST['concepto_id'];
		 }
	if( isset($_POST['nivel_id']) ) {
			$nivel_id = $_POST['nivel_id'];
		 }
	if( isset($_POST['vigencia_inicial']) ) {
			$vigencia_inicial = $_POST['vigencia_inicial'];
		 }
	if( isset($_POST['vigencia_final']) ) {
			$vigencia_final = $_POST['vigencia_final'];
		 }
	if( isset($_POST['semestre']) ) {
			$semestre = $_POST['semestre'];
		 }
		
	try {
	
		$sql = "UPDATE concepto_nivel SET " 
			//."concepto_id= '".$concepto_id."', "
			//."nivel_id= '".$nivel_id."', "
			."vigencia_inicial= '".$vigencia_inicial."', "
			."vigencia_final= '".$vigencia_final."', "
			."semestre= '".$semestre."' "
			." WHERE concepto_nivel_id=".$_POST['concepto_nivel_id'];
		$query = $pdo->prepare($sql);
		$query->execute();
		$pdo = null;
		
		header('Location: consultar_relacion.php');
		unset($pdo);
		unset($query);
	} catch (PDOException $e) {
		print "¡Error!: " . $e->getMessage() . "<br/>";
		die();
	}
	?>