<?php
require_once "../../config.php";

if( isset($_POST['nivel_id']) ) {
    $nivel_id = $_POST['nivel_id'];
}
if( isset($_POST['vigencia_inicial']) ) {
    $vigencia_inicial = $_POST['vigencia_inicial'];
}

if( isset($_POST['vigencia_final']) ) {
    $vigencia_final = $_POST['vigencia_final'];
}     
 
if( isset($_POST['semestre']) ) {
    $semestre = $_POST['semestre'];
}     
	
if( isset($_POST['estado']) ) {
    $estado = $_POST['estado'];
}     

try {
    $sql = "INSERT INTO concepto_nivel (concepto_id, nivel_id, vigencia_inicial, 
	vigencia_final, semestre) VALUES (
	'".$_POST['concepto']."','".$_POST['nivel']."','".$_POST['vigenciaI']."',
	'".$_POST['vigenciaF']."','".$_POST['semestre']."')";

    $query = $pdo->prepare($sql);
    $query->execute();

    $pdo = null;
    unset($pdo);
    unset($query);
    header('Location: consultar_relacion.php');
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>