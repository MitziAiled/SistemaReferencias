<?php
session_start();
 
if(isset($_SESSION["loggedin"])){
  header("location: ../dashboard.php");
  exit;
}

date_default_timezone_set('America/Mexico_City');

require_once "../../config.php";

if(!empty($_POST['nombre']) && !empty($_POST['correo'])) {
    if(isset($_POST["correo"])){
        $correo_electronico = trim($_POST["correo"]);
    }

    if(isset($_POST["nombre"])){
        $nombre = trim($_POST["nombre"]);
    }

    if(isset($_POST["primer_apellido"])){
        $primer_apellido = trim($_POST["primer_apellido"]);
    }

    if (!empty(trim($_POST["segundo_apellido"]))){
        $segundo_apellido = trim($_POST["segundo_apellido"]);
    }

    if (!empty(trim($_POST["cantidad_solicitada"]))){
        $cantidad_solicitada = trim($_POST["cantidad_solicitada"]);
    }

    if ($_POST["concepto_id"] > 0) {
        $concepto_id = $_POST["concepto_id"];
    }elseif($_POST["concepto_id"] == 0) {
        echo "<script>
                    alert('Seleccione un concepto');
                    window.location= 'generar_ref_ext.php'
            </script>";
    }

    try{ 
        $nivel_id=31;
        $no_control = intval(rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9)); 
        $no_banco =intval(rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9));
        $num = 22;
        $no_ref_ban = $nivel_id.$no_control.$concepto_id.$num.$no_banco;

        $sql = "SELECT concepto_id, nombre, descripcion, monto 
        FROM concepto WHERE `concepto_id`=:concepto_id";
        $query = $pdo->prepare($sql);
        $query -> bindParam(':concepto_id', $concepto_id, PDO::PARAM_INT);
        $query->execute();
        $conceptos = $query->fetchAll();
        $concepto = $conceptos[0];
        
        $concepto_nombre = $concepto['nombre'];
        $concepto_desc = $concepto['descripcion'];
        $concepto_monto = $concepto['monto'];
        $monto_total = $concepto_monto * $cantidad_solicitada;

        $date = date('Y-m-d h:i:s');
        $date_fin = strtotime('+4 day', strtotime($date));
        $date_fin = date('Y-m-d h:i:s', $date_fin);

        $sql = "INSERT INTO referencia (concepto_id, fecha_generada, fecha_expiracion, monto, numero_ref_banco,cantidad_solicitada, estado";
        $sqlValues = "VALUES ('".$concepto_id."','".$date."','".$date_fin."','".$monto_total."','".$no_ref_ban."','".$cantidad_solicitada."',0";
        $sql .= ") ".$sqlValues.");";

        $nombrec= $nombre." ".$primer_apellido." ".$segundo_apellido;
        $datosR = array($nombrec,$correo_electronico,$concepto_nombre,$no_ref_ban,$monto_total,$date_fin);
        if($stmt = $pdo->prepare($sql)) {
            if($stmt->execute()){
            } else{
                alert("El proceso no se pudo ejecutar. Intenta más tarde.");
            }
        }
        
    }catch (PDOException $e) {
        print "¡Error!: " . $e->getMessage() . "<br/>";
        die();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Fonts and icons -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- Favicon -->
    <link rel="icon" href="../static/favicon.ico">
    <!-- Material Kit CSS -->
    <link href="../../assets/css/material-dashboard.css?v=1" rel="stylesheet" />

    <style>
        body {
            background-image: url('../static/bg-login.jpeg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            height:100%;
        }
    </style>
    
    <title>Registro</title>
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-primary sticky-top">
        <div class="container">
            <a class="navbar-brand" href="../../index.php">Referencias</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Inicio de sesión</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../registro.php">Registro<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="generar_ref_ext.php">Generador de referencia</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-10 shadow-lg p-3 bg-white rounded">
                <div class="card-body">
                <?php if(!empty($_POST['nombre']) && !empty($_POST['correo'])) { ?>
                <h2>Información bancaria para deposito</h2>
                    
                   <b> Nombre: </b><?php echo $nombre?><br>
                   <b>Correo:</b><?php echo $correo_electronico?><br>
                   <b> Banco:</b> BANCOMER <br>
                   <b>Clave CIE:</b> 1369296 <br>
                   <b>Institución:</b>	TECNOLOGICO NACIONAL DE MEXICO <br>
                   <b>Concepto:</b> <?php echo $concepto_nombre?> <br>
                   <b>Número de Referencia:</b>	<?php echo $no_ref_ban?> <br>
                   <b>Importe:</b> <?php echo $monto_total?> <br>
                   <b>Fecha Limite de Pago:</b>	<?php echo $date_fin?> <br>

                   <textarea class="form-control"  rows="8" readonly>
                    A continuación, se en listan los medios habilitados para la recepción de pagos al Instituto Tecnológico de León:
                        Bancomer en algunas de sus sucursales no acepta pagos por ventanilla, te sugerimos estas opciones.
                        PRACTICAJA (Recepción en efectivo. Servicio 24 x 7).
                        CAJERO AUTOMATICO (Servicio 24 x 7 con cargo a cuenta Bancomer en el módulo de "Pago de Servicios").
                        BANCOMER MOVIL (Servicio 24 x 7 con cargo a cuenta Bancomer en el módulo de "Pago de Servicios").
                        CIE INTERBANCARIO (A través de Banca Electrónica Otros Bancos con la cuenta CLABE 012914002013692969.
                        BANCA ELECTRONICA BANCOMER (Servicio 24 x 7 con cargo a cuenta Bancomer en el módulo de "Pago de Servicios").
                   </textarea>
                <?php } ?>
                </div>
            </div>
        </div>
    </div>    
</body>
</html>