<!------------------- LÓGICA BACKEND------------------------------------------------->
<?php
session_start();
 
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: ../../index.php");
  exit;
}

if (isset($_SESSION["loggedin"]) && $_SESSION["rol_id"] == 11) {
  header("location: ../dashboard.php");
}

require_once "../../config.php";

$fecha_err = $estado_err = $monto_err = $tipo_pago_err = "";
$referencia_id = $fecha_pago = $monto_pagado = $estado = $tipo_pago = "";
$numero_ref_banco= $fecha_generada=$fecha_expiracion= $nombre= $cantidad_solicitada= $monto= $fecha_pago= $tipo_pago=$monto_pagado="";


/******* PARA OBTENER REFERENCIA *************************/
if(isset($_POST["referencia_id"])){
    $sql="SELECT r.referencia_id, r.numero_ref_banco, r.fecha_generada, r.fecha_expiracion, c.nombre, r.cantidad_solicitada, 
    r.monto, r.estado, r.fecha_pago, r.tipo_pago, r.monto_pagado FROM referencia AS r INNER JOIN concepto AS c 
    WHERE r.concepto_id=c.concepto_id AND referencia_id=".$_POST["referencia_id"];
	$query = $pdo->prepare($sql);
	$query->execute();
	$referencia = $query->fetchAll(PDO::FETCH_OBJ);
	
	// Guardamos los datos de lareferencia
    $referencia_id=$referencia[0]->referencia_id;
    $numero_ref_banco= $referencia[0]->numero_ref_banco; 
    $fecha_generada=$referencia[0]->fecha_generada; 
    $fecha_expiracion=$referencia[0]->fecha_expiracion;
    $nombre=$referencia[0]->nombre; 
    $cantidad_solicitada=$referencia[0]->cantidad_solicitada;
    $monto=$referencia[0]->monto;
    $estado=$referencia[0]->estado;
    $fecha_pago=$referencia[0]->fecha_pago;
    $tipo_pago=$referencia[0]->tipo_pago;
    $monto_pagado=$referencia[0]->monto_pagado;
    
    unset($query);
} elseif($_SERVER["REQUEST_METHOD"] == "POST"){
    $referencia_id = $_POST["id"];

    if(empty(trim($_POST["no_referencia"]))){
        $numero_ref_err = "Este campo es obligatorio.";     
    } else{
        $numero_ref_banco = trim($_POST["no_referencia"]);
    }

    if(empty(trim($_POST["fecha_generada"]))){
        $fecha_g_err = "Este campo es obligatorio.";     
    } else{
        $fecha_generada= trim($_POST["fecha_generada"]);
    }

    if(empty(trim($_POST["fecha_expiracion"]))){
        $fecha_e_err = "Este campo es obligatorio.";     
    } else{
        $fecha_expiracion= trim($_POST["fecha_expiracion"]);
    }

    if(empty(trim($_POST["concepto"]))){
        $concepto_err = "Este campo es obligatorio.";     
    } else{
        $nombre= trim($_POST["concepto"]);
    }

    if(empty(trim($_POST["cantidad_solicitada"]))){
        $cantidad_err = "Este campo es obligatorio.";     
    } else{
        $cantidad_solicitada= trim($_POST["cantidad_solicitada"]);
    }

    if(empty(trim($_POST["monto"]))){
        $monto1_err = "Este campo es obligatorio.";     
    } else{
        $monto = trim($_POST["monto"]);
    }

    if(empty(trim($_POST["monto_pagado"]))){
        $monto_err = "Este campo es obligatorio.";     
    } else{
        $monto_pagado = trim($_POST["monto_pagado"]);
    }

    if(empty(trim($_POST["fecha_pago"]))){
        $fecha_err = "Este campo es obligatorio.";     
    } else{
        $fecha_pago = trim($_POST["fecha_pago"]);
    }
  
    if ($_POST["estado"] == 0) {
        $estado_err = "Este campo es obligatorio.";
    } else {
        $estado = $_POST["estado"];
    } 

    if ($_POST["tipo_pago"] == 0) {
        $tipo_pago_err = "Este campo es obligatorio.";
    } elseif ($_POST["tipo_pago"] == 1) {
        $tipo_pago = "Efe";
    } elseif ($_POST["tipo_pago"] == 2) {
        $tipo_pago = "Tra";
    } 

	/**********************************************************************************************
									    ACTUALIZA DATOS 
	**********************************************************************************************/
    if(empty($fecha_err) && empty($estado_err) && empty($tipo_pago_err) && empty($monto_err)){

		// Update de campos obligatorios de pacientes
		$sqlUpdateReferencia = "UPDATE referencia
		SET 
		fecha_pago='".$fecha_pago."',
		tipo_pago='".$tipo_pago."',
		monto_pagado='".$monto_pagado."',
		estado=".$estado." WHERE referencia_id=".$referencia_id.";";

		$pdo->exec($sqlUpdateReferencia);
		
		header('Location: consulta_admin.php');

	}
} else {
	header('Location: consulta_admin.php');
}

unset($pdo);
?>

<!---------------------------------------------------------------------------------------
                                        LÓGICA FRONTEND
---------------------------------------------------------------------------------------->
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Favicon -->
  <link rel="icon" href="../../../static/favicon.ico">
  <!-- CSS Files -->
  <link href="../../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <title>Cambiar estado referencia</title>
</head>

<body>
    <!-- Inicio de todo -->
    <div class="wrapper ">
        <!-- Inicio menu de hamburguesa -->
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="../../assets/img/sidebar-1.jpg">
            <!-- Inicio titulo de sidebar -->
            <div class="logo">
                <a href="../dashboard.php" class="simple-text logo-normal">Referencias</a>
            </div>
            <!-- Fin titulo de sidebar -->

            <!-- Inicio elementos de menu -->
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item  ">
                        <a class="nav-link" href="../dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                        </a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="consulta_admin.php">
                            <i class="material-icons">description</i>
                            <p>Referencias</p>
                        </a>
                    </li>
                    <!-- Si es un administrador, mostrar los demas módulos -->
                    <?php
                    if(htmlspecialchars($_SESSION["rol_id"]) == 1) {?>
                        <li class="nav-item ">
                            <a class="nav-link" href="usuarios.php">
                                <i class="material-icons">person</i>
                                <p>Usuarios</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#">
                                <i class="material-icons">table_chart</i>
                                <p>Conceptos</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#">
                                <i class="material-icons">dynamic_feed</i>
                                <p>Aplicación a Conceptos</p>
                            </a>
                        </li>
                    <?php }
                    ?>
                </ul>
            </div>
            <!-- Fin elementos de menu -->
        </div>
        <!-- Fin menu de hamburguesa -->

        <!-- Inicio de panel -->
        <div class="main-panel">
            <!-- Inicio menú de logout -->
            <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <h1 class="navbar-brand">Usuarios</h1>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                    </button>
                    <div class="justify-content-end">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown" data-toggle="dropdown">
                                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">person</i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                                    <form action="../logout.php">
                                        <button style="cursor:pointer;width:93%;" type="submit" class="dropdown-item">Cerrar sesión</button>
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- Fin menú logout -->

            <!-- Inicio de dashboard -->
            <div class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h3 class="card-title">Modificación de Usuario</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card-title text-center mt-3">
                                        <form action="<?php $_SERVER["PHP_SELF"];?>" method="POST" onsubmit="return confirm('¿Realmente deseas modificar la referencia?');">
                                            
                                            <div class="form-row justify-content-around">
                                                <div class="form-group col-md-3 <?php echo (!empty($numero_ref_err)) ? : ''; ?>">
                                                    <label>No. de referecia bancaria</label>
                                                    <input type="text" name="no_referencia" class="form-control" value="<?php echo $numero_ref_banco; ?>" readonly>
                                                    <?php if(!empty($numero_ref_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $numero_ref_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>

                                                <div class="form-group col-md-3 <?php echo (!empty($fecha_g_err)) ? : ''; ?>">
                                                    <label>Fecha de referencia generada</label>
                                                    <input type="text" name="fecha_generada" class="form-control" value="<?php echo $fecha_generada; ?>" readonly>                                                    
                                                    <?php if(!empty($fecha_g_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $fecha_g_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>

                                                <div class="form-group col-md-3 <?php echo (!empty($fecha_e_err)) ? : ''; ?>">
                                                    <label>Fecha de expiración</label>
                                                    <input type="text" name="fecha_expiracion" class="form-control" value="<?php echo $fecha_expiracion; ?>" readonly>
                                                    <?php if(!empty($fecha_e_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $fecha_e_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>

                                            <div class="form-row justify-content-around mt-5">
                                                <div class="form-group col-md-3 <?php echo (!empty($concepto_err)) ? : ''; ?>">
                                                    <label>Concepto</label>
                                                    <input type="text" name="concepto" class="form-control" value="<?php echo $nombre; ?>" readonly>
                                                    <?php if(!empty($concepto_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $concepto_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>

                                                <div class="form-group col-md-3<?php echo (!empty($cantidad_err)) ? : ''; ?>">
                                                    <label>Cantidad</label>
                                                    <input type="number" name="cantidad_solicitada" class="form-control" value="<?php echo $cantidad_solicitada; ?>" readonly>
                                                    <?php if(!empty($cantidad_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $cantidad_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>

                                                <div class="form-group col-md-3 <?php echo (!empty($moto1_err)) ? : ''; ?>">
                                                    <label>Monto</label>
                                                    <input type="number" name="monto" class="form-control" value="<?php echo $monto; ?>" readonly>
                                                    <?php if(!empty($moto1_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $moto1_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>

                                            <div class="form-row justify-content-around mt-5">
                                                <div class="form-group col-md-3">
                                                    <label>Estado</label>
                                                    <select class="form-control selectpicker" data-style="btn btn-link" name="estado" <?php echo (!empty($estado_err)) ? : ''; ?>>
                                                        <option value="0" selected>Cambiar estado...</option>
                                                        <option value="1">Pagado</option>
                                                    </select><?php
                                                    if(!empty($estado_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $estado_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                                <div class="form-group col-md-3 <?php echo (!empty($fecha_err)) ? : ''; ?>">
                                                    <label>Fecha de pago</label>
                                                    <input type="date" name="fecha_pago" class="form-control"><?php
                                                    if(!empty($fecha_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $fecha_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                                <div class="form-group col-md-3">
                                                    <label>Tipo de pago</label>
                                                    <select class="form-control selectpicker" data-style="btn btn-link" name="tipo_pago" <?php echo (!empty($tipo_pago_err)) ? : ''; ?>>
                                                        <option value="0">Elige uno...</option>    
                                                        <option value="1">Efectivo</option>
                                                        <option value="2">Transferencia bancaria</option>
                                                    </select><?php
                                                    if(!empty($tipo_pago_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $tipo_pago_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>

                                            <div class="form-row justify-content-around mt-5">
                                                <div class="form-group col-md-3">
                                                    <label>Monto pagado</label>
                                                    <input type="number" step="any" min="0" name="monto_pagado" class="form-control"><?php
                                                    if(!empty($monto_err)){?>
                                                    <small style="padding:5px;" class="alert alert-danger" role="alert"><?php echo $monto_err; ?></small>
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <div class="row">
                                                <div class="col-md">
                                                    <a href="consulta_admin.php" role="button" class="btn btn-default">Cancelar</a>
                                                </div>
                                                <div class="col-md">
                                                    <button type="submit" class="btn btn-primary">Actualizar referencia</button>
                                                </div>
                                                <input type="hidden" name="id" value="<?php echo $referencia_id ?>">
                                                </div>
                                            </div>
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Fin de dashboard -->
        </div>
        <!-- Fin de panel -->
    </div>
    <!-- Inicio de todo -->
    
    <!--   Core JS Files   -->
    <script src="../assets/js/core/jquery.min.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap-material-design.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!-- Plugin for the momentJs  -->
    <script src="../assets/js/plugins/moment.min.js"></script>
    <!--  Plugin for Sweet Alert -->
    <script src="../assets/js/plugins/sweetalert2.js"></script>
    <!-- Forms Validations Plugin -->
    <script src="../assets/js/plugins/jquery.validate.min.js"></script>
    <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
    <script src="../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
    <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
    <script src="../assets/js/plugins/bootstrap-selectpicker.js"></script>
    <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
    <script src="../assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
    <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
    <script src="../assets/js/plugins/jquery.dataTables.min.js"></script>
    <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
    <script src="../assets/js/plugins/bootstrap-tagsinput.js"></script>
    <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
    <script src="../assets/js/plugins/jasny-bootstrap.min.js"></script>
    <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
    <script src="../assets/js/plugins/fullcalendar.min.js"></script>
    <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
    <script src="../assets/js/plugins/jquery-jvectormap.js"></script>
    <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="../assets/js/plugins/nouislider.min.js"></script>
    <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
    <!-- Library for adding dinamically elements -->
    <script src="../assets/js/plugins/arrive.min.js"></script>
    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <!-- Chartist JS -->
    <script src="../assets/js/plugins/chartist.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }

        }

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      //init DateTimePickers
      md.initFormExtendedDatetimepickers();
    });
  </script>
</body>

</html>