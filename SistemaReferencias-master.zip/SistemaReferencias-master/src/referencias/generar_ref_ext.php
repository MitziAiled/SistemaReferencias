<?php
session_start();

if(isset($_SESSION["loggedin"])){
    header("location: ../dashboard.php");
    exit;
}

require_once "../../config.php";

$correo_electronico = $nombre = $primer_apellido = $segundo_apellido="";
$correo_electronico_err = $nombre_err = $primer_apellido_err = $concepto_id_err = $cantidad_err = "";

$sql = 'SELECT c.concepto_id, c.nombre, c.descripcion, c.monto 
        FROM concepto AS c INNER JOIN concepto_nivel AS cn 
        WHERE c.concepto_id = cn.concepto_id AND c.estado=1 AND cn.nivel_id = 31 AND cn.semestre = 0 AND curdate() between cn.vigencia_inicial AND cn.vigencia_final
        GROUP BY c.concepto_id';
$query = $pdo->prepare($sql);
$query->execute();
$conceptosBD = $query->fetchAll(PDO::FETCH_OBJ);
$conceptos = array();

// Valida que haya registros de referencias
if ($query->rowCount() > 0) {
    foreach ($conceptosBD as $concepto) {
        $conceptos[] = $concepto;
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Fonts and icons -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- Favicon -->
    <link rel="icon" href="../../../static/favicon.ico">
    <!-- Material Kit CSS -->
    <link href="../../assets/css/material-dashboard.css?v=1" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <style>
        body {
            background-image: url('../../../static/bg-login.jpeg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
            height:100%;
        }
    </style>
    
    <title>Generar Referencia</title>
</head>

<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-sm bg-primary sticky-top">
        <div class="container">
            <a class="navbar-brand" href="../../index.php">Referencias</a>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../../index.php">Inicio de sesión<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../registro.php">Registro</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="generar_ref_ext.php">Generador de referencia</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- INICIO DE SESIÓN -->
    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-8 shadow-lg p-1 bg-white rounded">
                <div>
                    <h2 class="h3 text-center"><b>Generar referencia bancaria</b></h4>
                    <p class="text-center">Por favor ingresa todos tus datos para generar la referencia.</p>
				</div>
                <div class="card-body">
                    <form action="consulta_ext.php" method="post">
                        <div class="form-row justify-content-around">
                            <div class="form-group col-md-8">
                                <div class="row">
                                    <div class="col">
                                        <label for="">Correo:</label>
                                        <input type="email" name="correo" class="form-control" value="<?php echo $correo_electronico; ?>" required>
        
                                    </div>
                                    <div class="col">
                                        <label for="">Nombre:</label>
                                        <input type="text" name="nombre" class="form-control" value="<?php echo $nombre; ?>" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <label for="">Primer Apellido:</label>
                                        <input type="text" name="primer_apellido" class="form-control" value="<?php echo $primer_apellido; ?>" required>
                                    </div>
                                    <div class="col">
                                        <label for="">Segundo Apellido:</label>
                                        <input type="text" name="segundo_apellido" class="form-control" value="<?php echo $segundo_apellido; ?>"> 
                                    </div>
                                </div>
                            </div>
                        </div>
						<div class="form-row justify-content-around">
                            <div class="form-group col-md-8">
                                <div class="row">
                                    <div class="col">
                                        <label for="exampleFormControlSelect1">Concepto a pagar:</label>
                                        <select id="list_conceptos" class="form-control selectpicker" data-style="btn btn-link" name="concepto_id" required>
                                            <option value="0" selected>Elige uno...</option>
                                        <?php
                                            // Revisa si hay conceptos
                                            if (!empty($conceptos)) {
                                            foreach ($conceptos as $concepto) {
                                        ?>
                                        <option value="<?php echo ($concepto->concepto_id); ?>"><?php echo ($concepto->nombre); ?></option>
                                        <?php } } ?>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <label>Cantidad</label>
                                        <input type="number" class="form-control" name="cantidad_solicitada" value="1" placeholder="1">
                                    </div>
                                </div>
							</div>
						</div>
						<div class="form-row justify-content-around">
                            <div class="form-group col-md-8" id="autoc">
							</div>
						</div>
                        <div class="form-row justify-content-around">
                            <div class="form-group text-center col-md-4 col-xs-3">
                                <input style="white-space:normal;" type="submit" class="btn btn-primary btn-block" data-toggle="modal" data-target="#ventanaModal" value="Generar referencia">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<script type="text/javascript">
	$(document).ready(function(){
		$('#list_conceptos').val();
		autocompletar();

		$('#list_conceptos').change(function(){
			autocompletar();
		});
	})
</script>
<script type="text/javascript">
	function autocompletar(){
		$.ajax({
			type:"POST",
			url:"autocompletar.php",
			data:"concepto=" + $('#list_conceptos').val(),
			success:function(r){
				$('#autoc').html(r);
			}
		});
	}
</script>
</html>
