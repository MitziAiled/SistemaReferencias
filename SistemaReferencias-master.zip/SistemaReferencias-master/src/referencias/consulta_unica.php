<?php 
session_start();
 
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: ../../index.php");
  exit;
}

if (isset($_SESSION["loggedin"]) && $_SESSION["rol_id"] == 11) {
  header("location: ../dashboard.php");
}

require_once "../../config.php";

if(!empty($_POST['numero_control']) && !empty($_POST['nombre'])) {

  if (strlen(trim($_POST["numero_control"])) <= 7 || strlen(trim($_POST["numero_control"])) >= 10) {
      echo "<script>
                    alert('Ingresa un número de control válido.');
                    window.location= 'generar_ref.php'
            </script>";
  } else{
      $numero_control = trim($_POST["numero_control"]);
  }

  if(isset($_POST["nombre"])){
      $nombre = trim($_POST["nombre"]);
  }

  if ((trim($_POST["semestre"]) < 1) || (trim($_POST["semestre"]) > 13)) {
      echo "<script>
                    alert('Ingresa un semestre válido.');
                    window.location= 'generar_ref.php'
            </script>";
  } else{
      $semestre = trim($_POST["semestre"]);
  }


  if ($_POST["nivel_id"] > 0) {
    $nivel_id = $_POST["nivel_id"];
  }elseif($_POST["nivel_id"] == 0) {
      echo "<script>
                  alert('Seleccione el nivel académico');
                  window.location= 'generar_ref.php'
          </script>";
  }

  if (isset($_POST["cantidad_solicitada"])){
      $cantidad_solicitada = trim($_POST["cantidad_solicitada"]);
  }

  if ($_POST["concepto_id"] > 0) {
    $concepto_id = $_POST["concepto_id"];
  }elseif($_POST["concepto_id"] == 0) {
      echo "<script>
                  alert('Seleccione un concepto');
                  window.location= 'generar_ref.php'
          </script>";
  }

  if(isset($_POST["fecha_generada"])){
      $fecha_generada = trim($_POST["fecha_generada"]);
  }

  if(isset($_POST["fecha_expiracion"])){
      $fecha_expiracion = trim($_POST["fecha_expiracion"]);
  }

  try{  
      $sql = "SELECT concepto_id, nombre, descripcion, monto 
      FROM concepto WHERE `concepto_id`=:concepto_id";
      $query = $pdo->prepare($sql);
      $query -> bindParam(':concepto_id', $concepto_id, PDO::PARAM_INT);
      $query->execute();
      $conceptos = $query->fetchAll();
      $concepto = $conceptos[0];
      
      $concepto_nombre = $concepto['nombre'];
      $concepto_desc = $concepto['descripcion'];
      $concepto_monto = $concepto['monto'];
      $monto_total = $concepto_monto * $cantidad_solicitada;

      $sql = "SELECT usuario_id FROM usuario WHERE `numero_control`=:numero_control";
      $query = $pdo->prepare($sql);
      $query -> bindParam(':numero_control', $numero_control, PDO::PARAM_INT);
      $query->execute();
      $usuarios = $query->fetchAll();
      
      if(!empty($usuarios)){
        $usuario = $usuarios[0];
        $usuario_id = $usuario['usuario_id'];
      }
      
      $no_banco =intval(rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9));
      $num = 21;

      if(!empty($usuario_id)){
        $no_ref_ban = $nivel_id.$numero_control.$concepto_id.$num.$no_banco;
        $sql = "INSERT INTO referencia (usuario_id,concepto_id, fecha_generada, fecha_expiracion, monto, numero_ref_banco,cantidad_solicitada, estado";
        $sqlValues = "VALUES ('".$usuario_id."','".$concepto_id."','".$fecha_generada."','".$fecha_expiracion."','".$monto_total."','".$no_ref_ban."','".$cantidad_solicitada."',0";
        $sql .= ") ".$sqlValues.");";
        if($stmt = $pdo->prepare($sql)) {
            if($stmt->execute()){
            } else{
                alert("El proceso no se pudo ejecutar. Intenta más tarde.");
            }
        }
      }else{
        $no_ref_ban = $nivel_id.$numero_control.$concepto_id.$num.$no_banco;
        $sql = "INSERT INTO referencia (concepto_id, fecha_generada, fecha_expiracion, monto, numero_ref_banco,cantidad_solicitada, estado";
        $sqlValues = "VALUES ('".$concepto_id."','".$fecha_generada."','".$fecha_expiracion."','".$monto_total."','".$no_ref_ban."','".$cantidad_solicitada."',0";
        $sql .= ") ".$sqlValues.");";
        if($stmt = $pdo->prepare($sql)) {
            if($stmt->execute()){
            } else{
                alert("El proceso no se pudo ejecutar. Intenta más tarde.");
            }
        }
      }
  }catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
  }
}

?>

<!---------------------------------------------------------------------------------------
                                        LÓGICA FRONTEND
----------------------------------------------------------------------------------------> 
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Favicon -->
  <link rel="icon" href="../../static/favicon.ico">
  <!-- CSS Files -->
  <link href="../../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />

  <title>Historial</title>
</head>

<body>
    <!-- Inicio de todo -->
    <div class="wrapper ">
        <!-- Inicio menu de hamburguesa -->
        <div class="sidebar" data-color="purple" data-background-color="white" data-image="../../../assets/img/sidebar-1.jpg">
            <!-- Inicio titulo de sidebar -->
            <div class="logo">
                <a href="../../dashboard.php" class="simple-text logo-normal">Referencias</a>
            </div>
            <!-- Fin titulo de sidebar -->

            <!-- Inicio elementos de menu -->
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="nav-item  ">
                        <a class="nav-link" href="../../dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                        </a>
                    </li>
                    <?php
                    if(htmlspecialchars($_SESSION["rol_id"]) == 11) {?>
                    <li class="nav-item ">
                        <a class="nav-link" href="consulta_admin.php">
                            <i class="material-icons">description</i>
                            <p>Referencias</p>
                        </a>
                    </li>
                    <?php } else{ ?>
                    <li class="nav-item ">
                        <a class="nav-link" href="consulta_est.php">
                            <i class="material-icons">description</i>
                            <p>Referencias</p>
                        </a>
                    </li>
                    <?php } ?>
                    <!-- Si es un administrador, mostrar los demas módulos -->
                    <?php
                    if(htmlspecialchars($_SESSION["rol_id"]) == 1) {?>
                        <li class="nav-item ">
                            <a class="nav-link" href="#">
                                <i class="material-icons">person</i>
                                <p>Usuarios</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#">
                                <i class="material-icons">table_chart</i>
                                <p>Conceptos</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="#">
                                <i class="material-icons">dynamic_feed</i>
                                <p>Aplicación a Conceptos</p>
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </div>
            <!-- Fin elementos de menu -->
        </div>
        <!-- Fin menu de hamburguesa -->

        <!-- Inicio de panel -->
        <div class="main-panel">
            <!-- Inicio menú de logout -->
            <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <h1 class="navbar-brand">Referencias</h1>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                        <span class="navbar-toggler-icon icon-bar"></span>
                    </button>
                    <div class="justify-content-end">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown" data-toggle="dropdown">
                                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">person</i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                                    <form action="../../logout.php">
                                        <button style="cursor:pointer;width:93%;" type="submit" class="dropdown-item">Cerrar sesión</button>
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- Fin menú logout -->

            <!-- Inicio de dashboard -->
            <div class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h3 class="card-title">Referencia única</h3>
                        </div>
                        <div class="card-body">
                        <?php if(!empty($_POST['numero_control']) && !empty($_POST['nombre'])) { ?>
                          <h2>Información bancaria para deposito</h2>
                              
                            <b> Nombre: </b><?php echo $nombre?><br>
                            <b> Banco:</b> BANCOMER <br>
                            <b>Clave CIE:</b> 1369296 <br>
                            <b>Institución:</b>	TECNOLOGICO NACIONAL DE MEXICO <br>
                            <b>Concepto:</b> <?php echo $concepto_nombre?> <br>
                            <b>Número de Referencia:</b>	<?php echo $no_ref_ban?> <br>
                            <b>Importe:</b> <?php echo $monto_total?> <br>
                            <b>Fecha Limite de Pago:</b>	<?php echo $fecha_expiracion?> <br>

                            <textarea class="form-control"  rows="8" readonly>
                              A continuación, se en listan los medios habilitados para la recepción de pagos al Instituto Tecnológico de León:
                                  Bancomer en algunas de sus sucursales no acepta pagos por ventanilla, te sugerimos estas opciones.
                                  PRACTICAJA (Recepción en efectivo. Servicio 24 x 7).
                                  CAJERO AUTOMATICO (Servicio 24 x 7 con cargo a cuenta Bancomer en el módulo de "Pago de Servicios").
                                  BANCOMER MOVIL (Servicio 24 x 7 con cargo a cuenta Bancomer en el módulo de "Pago de Servicios").
                                  CIE INTERBANCARIO (A través de Banca Electrónica Otros Bancos con la cuenta CLABE 012914002013692969.
                                  BANCA ELECTRONICA BANCOMER (Servicio 24 x 7 con cargo a cuenta Bancomer en el módulo de "Pago de Servicios").
                            </textarea>
                              <?php } ?>
                        <div class="col-md">
                        <a href="consulta_admin.php" role="button" class="btn btn-default">Cerrar</a>
                      </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- Fin de dashboard -->
        </div>
        <!-- Fin de panel -->
    </div>
    <!-- Inicio de todo -->
    
        <!--   Core JS Files   -->
    <script src="../../assets/js/core/jquery.min.js"></script>
    <script src="../../assets/js/core/popper.min.js"></script>
    <script src="../../assets/js/core/bootstrap-material-design.min.js"></script>
    <script src="../../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!-- Plugin for the momentJs  -->
    <script src="../../assets/js/plugins/moment.min.js"></script>
    <!--  Plugin for Sweet Alert -->
    <script src="../../assets/js/plugins/sweetalert2.js"></script>
    <!-- Forms Validations Plugin -->
    <script src="../../assets/js/plugins/jquery.validate.min.js"></script>
    <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
    <script src="../../assets/js/plugins/jquery.bootstrap-wizard.js"></script>
    <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
    <script src="../../assets/js/plugins/bootstrap-selectpicker.js"></script>
    <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
    <script src="../../assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
    <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
    <script src="../../assets/js/plugins/jquery.dataTables.min.js"></script>
    <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
    <script src="../../assets/js/plugins/bootstrap-tagsinput.js"></script>
    <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
    <script src="../../assets/js/plugins/jasny-bootstrap.min.js"></script>
    <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
    <script src="../../assets/js/plugins/fullcalendar.min.js"></script>
    <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
    <script src="../../assets/js/plugins/jquery-jvectormap.js"></script>
    <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="../../assets/js/plugins/nouislider.min.js"></script>
    <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
    <!-- Library for adding dinamically elements -->
    <script src="../../assets/js/plugins/arrive.min.js"></script>
    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <!-- Chartist JS -->
    <script src="../../assets/js/plugins/chartist.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  
    <script>
    $(document).ready(function() {
        $().ready(function() {
            $sidebar = $('.sidebar');
            $sidebar_img_container = $sidebar.find('.sidebar-background');
            $full_page = $('.full-page');
            $sidebar_responsive = $('body > .navbar-collapse');
            window_width = $(window).width();
            fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();
            if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
                if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
                    $('.fixed-plugin .dropdown').addClass('open');
                }
            }

            $('.fixed-plugin a').click(function(event) {
                // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
                if ($(this).hasClass('switch-trigger')) {
                    if (event.stopPropagation) {
                        event.stopPropagation();
                    } else if (window.event) {
                        window.event.cancelBubble = true;
                    }
                }
            });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
    <script>
    $(document).ready(function() {
        //init DateTimePickers
        md.initFormExtendedDatetimepickers();
    });
    </script>
</body>
</html>