<?php
require_once "../../config.php";

if(isset($_POST['concepto'])){
$concepto=$_POST['concepto'];
if($concepto > 0){
    $sql = "SELECT  c.descripcion, c.monto 
        FROM concepto AS c WHERE c.concepto_id ='$concepto'";
    $query = $pdo->prepare($sql);
    $query->execute();
    $conceptos = $query->fetchAll();
    $concep = $conceptos[0];
    $concepto_desc = $concep['descripcion'];
    $concepto_monto = $concep['monto'];

    $cadena = " <div class='form-group col-md-14' id='autoc'>
                <div class='row' id='autoc'>
                    <div class='col'>
                        <label>Precio</label>
                        <input class='form-control' id='monto_concepto' value='".$concepto_monto."' type='text' readonly>
                    </div>
                    <div class='col'>
                        <label>Descripcion</label>
                        <textarea class='form-control' id='descripcion' rows='3' readonly>$concepto_desc</textarea>
                    </div>
            </div>
        </div>";
	echo  $cadena;
}
}

if(isset($_POST['semestre-concepto'])){
    $semestre=$_POST['semestre-concepto'];
    //consultar conceptos permitidos para el nivel del usuario
    $sql = 'SELECT c.concepto_id, c.nombre, c.descripcion, c.monto 
    FROM concepto AS c INNER JOIN concepto_nivel AS cn 
    WHERE c.concepto_id = cn.concepto_id AND c.estado=1 AND cn.semestre='.$semestre;
    $query = $pdo->prepare($sql);
    $query->execute();
    $conceptosBD = $query->fetchAll(PDO::FETCH_OBJ);
    $conceptos = array();

    // Valida que haya registros de conceptos
    if ($query->rowCount() > 0) {
    foreach ($conceptosBD as $concepto) {
    $conceptos[] = $concepto;
    }
    }
        $cadena = '
         <div id="mostra_conceptos">
            <select id="list_conceptos" class="form-control selectpicker" data-style="btn btn-link" name="concepto_id">
                <option value="0" selected>Elige uno...</option>
                <?php
                // Revisa si hay conceptos
            if (!empty($conceptos)) {
                foreach ('.$conceptos.' as '.$concepto.') { ?>
                    <option value="<?php echo ('.$concepto.'->concepto_id); ?>"><?php echo ('.$concepto.'->nombre); ?></option>
            <?php } } ?>
            </select></div>';
    echo  $cadena;
}


?>